import { i as __toESM } from "../_runtime.mjs";
import { c as require_jsx_runtime, l as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { a as BufferAttribute, c as CylinderGeometry, l as Object3D, n as useFrame, o as BufferGeometry, r as useThree, s as CanvasTexture, t as Canvas, u as SRGBColorSpace } from "../_libs/@react-three/fiber+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/khatai-scene-DLMeUENy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function hash2(x, y) {
	const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123;
	return s - Math.floor(s);
}
function noise(x, y) {
	const ix = Math.floor(x);
	const iy = Math.floor(y);
	const fx = x - ix;
	const fy = y - iy;
	const ux = fx * fx * (3 - 2 * fx);
	const uy = fy * fy * (3 - 2 * fy);
	return hash2(ix, iy) * (1 - ux) * (1 - uy) + hash2(ix + 1, iy) * ux * (1 - uy) + hash2(ix, iy + 1) * (1 - ux) * uy + hash2(ix + 1, iy + 1) * ux * uy;
}
function fbm(x, y) {
	return noise(x, y) * .55 + noise(x * 2.15, y * 2.15) * .28 + noise(x * 4.4, y * 4.4) * .17;
}
function buildKhataiGeometry() {
	const geo = new CylinderGeometry(1.28, 1.32, .3, 96, 8, false);
	const pos = geo.attributes.position;
	for (let i = 0; i < pos.count; i++) {
		const x = pos.getX(i);
		const y = pos.getY(i);
		const z = pos.getZ(i);
		const r = Math.hypot(x, z);
		const angle = Math.atan2(z, x);
		const wrinkle = Math.sin(angle * 7) * .014 + Math.sin(angle * 13 + 1.1) * .009 + (fbm(x * 2.4, z * 2.4) - .5) * .03;
		let ny = y;
		if (y > .04) {
			const t = Math.min(r / 1.28, 1);
			ny += (1 - t * t) * .07;
			ny += (fbm(x * 6.5, z * 6.5) - .45) * .05;
			if (fbm(x * 9, z * 9) > .72) ny -= .018;
		} else if (y < -.04) ny -= (fbm(x * 5, z * 5) - .5) * .012;
		pos.setXYZ(i, x * (1 + wrinkle), ny, z * (1 + wrinkle));
	}
	geo.computeVertexNormals();
	return geo;
}
function makeCookieMaps() {
	const size = 512;
	const albedo = document.createElement("canvas");
	albedo.width = albedo.height = size;
	const ctx = albedo.getContext("2d");
	if (!ctx) throw new Error("canvas");
	const g = ctx.createRadialGradient(size * .5, size * .48, size * .04, size * .5, size * .5, size * .55);
	g.addColorStop(0, "#f0c57a");
	g.addColorStop(.28, "#e0a84b");
	g.addColorStop(.62, "#c47a30");
	g.addColorStop(.86, "#9a5420");
	g.addColorStop(1, "#6d3514");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, size, size);
	const img = ctx.getImageData(0, 0, size, size);
	const d = img.data;
	for (let i = 0; i < d.length; i += 4) {
		const n = (Math.random() - .5) * 32;
		d[i] = Math.max(0, Math.min(255, d[i] + n));
		d[i + 1] = Math.max(0, Math.min(255, d[i + 1] + n * .82));
		d[i + 2] = Math.max(0, Math.min(255, d[i + 2] + n * .45));
	}
	ctx.putImageData(img, 0, 0);
	for (let i = 0; i < 220; i++) {
		const x = Math.random() * size;
		const y = Math.random() * size;
		ctx.fillStyle = `rgba(82, 38, 12, ${.06 + Math.random() * .2})`;
		ctx.beginPath();
		ctx.ellipse(x, y, 1 + Math.random() * 5, .6 + Math.random() * 2.4, Math.random() * Math.PI, 0, Math.PI * 2);
		ctx.fill();
	}
	for (let i = 0; i < 50; i++) {
		ctx.fillStyle = `rgba(255, 236, 200, ${.12 + Math.random() * .22})`;
		ctx.beginPath();
		ctx.arc(Math.random() * size, Math.random() * size, .6 + Math.random() * 1.1, 0, Math.PI * 2);
		ctx.fill();
	}
	const bump = document.createElement("canvas");
	bump.width = bump.height = size;
	const bctx = bump.getContext("2d");
	if (!bctx) throw new Error("canvas");
	bctx.fillStyle = "#808080";
	bctx.fillRect(0, 0, size, size);
	const bimg = bctx.getImageData(0, 0, size, size);
	const bd = bimg.data;
	for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
		const v = Math.floor(fbm(x * .045, y * .045) * 255);
		const i = (y * size + x) * 4;
		bd[i] = bd[i + 1] = bd[i + 2] = v;
		bd[i + 3] = 255;
	}
	bctx.putImageData(bimg, 0, 0);
	const albedoTex = new CanvasTexture(albedo);
	albedoTex.colorSpace = SRGBColorSpace;
	albedoTex.anisotropy = 8;
	albedoTex.needsUpdate = true;
	const bumpTex = new CanvasTexture(bump);
	bumpTex.needsUpdate = true;
	return {
		albedoTex,
		bumpTex
	};
}
function Khatai({ reducedMotion }) {
	const group = (0, import_react.useRef)(null);
	const geo = (0, import_react.useMemo)(() => buildKhataiGeometry(), []);
	const maps = (0, import_react.useMemo)(() => makeCookieMaps(), []);
	(0, import_react.useEffect)(() => {
		return () => {
			geo.dispose();
			maps.albedoTex.dispose();
			maps.bumpTex.dispose();
		};
	}, [geo, maps]);
	useFrame((state, delta) => {
		if (!group.current || reducedMotion) return;
		const d = Math.min(delta, .1);
		group.current.rotation.y += .32 * d;
		group.current.position.y = Math.sin(state.clock.elapsedTime * .65) * .045;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref: group,
		position: [
			0,
			.08,
			0
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				geometry: geo,
				castShadow: true,
				receiveShadow: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
					map: maps.albedoTex,
					bumpMap: maps.bumpTex,
					bumpScale: .085,
					roughness: .5,
					metalness: .03,
					clearcoat: .62,
					clearcoatRoughness: .26,
					sheen: .55,
					sheenColor: "#f3d9a0",
					sheenRoughness: .42
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				position: [
					0,
					.03,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
					1.27,
					.018,
					8,
					64
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#7a3f16",
					roughness: .72
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.02,
					.23,
					.04
				],
				rotation: [
					.55,
					.4,
					.7
				],
				scale: [
					.1,
					.048,
					.062
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					1,
					14,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#6f9444",
					roughness: .55
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.015,
					.245,
					.05
				],
				rotation: [
					.55,
					.4,
					.7
				],
				scale: [
					.055,
					.02,
					.03
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					1,
					10,
					8
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#c9d98a",
					roughness: .4
				})]
			})
		]
	});
}
function Crumbs({ reducedMotion }) {
	const ref = (0, import_react.useRef)(null);
	const n = 16;
	const dummy = (0, import_react.useMemo)(() => new Object3D(), []);
	const seeds = (0, import_react.useMemo)(() => Array.from({ length: n }, (_, i) => ({
		r: 1.55 + i % 5 * .14,
		y: -.08 + i % 7 * .05,
		speed: .12 + i % 4 * .045,
		phase: i * .73,
		scale: .035 + i % 3 * .014
	})), []);
	useFrame((state) => {
		if (!ref.current) return;
		const t = reducedMotion ? 0 : state.clock.elapsedTime;
		seeds.forEach((s, i) => {
			dummy.position.set(Math.cos(t * s.speed + s.phase) * s.r, s.y + Math.sin(t * .55 + s.phase) * .16, Math.sin(t * s.speed + s.phase) * s.r * .72);
			dummy.rotation.set(t * .35 + i, t * .22, .4);
			dummy.scale.set(s.scale, s.scale * .45, s.scale * .7);
			dummy.updateMatrix();
			ref.current.setMatrixAt(i, dummy.matrix);
		});
		ref.current.instanceMatrix.needsUpdate = true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("instancedMesh", {
		ref,
		args: [
			void 0,
			void 0,
			n
		],
		castShadow: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
			1,
			1,
			1
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: "#c47a30",
			roughness: .82
		})]
	});
}
function Dust({ reducedMotion, count, rise, size, color, spread }) {
	const ref = (0, import_react.useRef)(null);
	const geo = (0, import_react.useMemo)(() => {
		const g = new BufferGeometry();
		const a = new Float32Array(count * 3);
		for (let i = 0; i < count; i++) {
			a[i * 3] = (Math.random() - .5) * spread;
			a[i * 3 + 1] = Math.random() * 2.2 - .2;
			a[i * 3 + 2] = (Math.random() - .5) * spread * .8;
		}
		g.setAttribute("position", new BufferAttribute(a, 3));
		return g;
	}, [count, spread]);
	(0, import_react.useEffect)(() => () => geo.dispose(), [geo]);
	useFrame((_, delta) => {
		if (reducedMotion || !ref.current) return;
		const d = Math.min(delta, .1);
		const arr = ref.current.geometry.attributes.position.array;
		for (let i = 0; i < count; i++) {
			arr[i * 3 + 1] += d * rise;
			arr[i * 3] += Math.sin(arr[i * 3 + 1] * 2.2 + i) * d * .05;
			if (arr[i * 3 + 1] > 2.3) {
				arr[i * 3 + 1] = -.2;
				arr[i * 3] = (Math.random() - .5) * spread;
				arr[i * 3 + 2] = (Math.random() - .5) * spread * .8;
			}
		}
		ref.current.geometry.attributes.position.needsUpdate = true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("points", {
		ref,
		geometry: geo,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointsMaterial", {
			color,
			size,
			transparent: true,
			opacity: .55,
			depthWrite: false,
			sizeAttenuation: true
		})
	});
}
function AdaptiveCamera() {
	const { camera, size } = useThree();
	(0, import_react.useEffect)(() => {
		camera.position.set(0, size.width < 640 ? 1.35 : 1.12, size.width < 640 ? 3.7 : 3.05);
		camera.lookAt(0, .08, 0);
	}, [camera, size]);
	return null;
}
function Scene({ reducedMotion }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdaptiveCamera, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", {
			intensity: .7,
			color: "#f3e2c0"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: [
				3.2,
				5.4,
				2.2
			],
			intensity: 2.1,
			color: "#ffe6bf",
			castShadow: true
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			position: [
				-2.4,
				2.1,
				1.6
			],
			intensity: 16,
			distance: 10,
			decay: 2,
			color: "#e8b968"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			position: [
				1.6,
				.4,
				-2.2
			],
			intensity: 8,
			distance: 8,
			decay: 2,
			color: "#c9973d"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Khatai, { reducedMotion }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crumbs, { reducedMotion }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dust, {
			reducedMotion,
			count: 70,
			rise: .1,
			size: .032,
			color: "#f5efdd",
			spread: 4.2
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dust, {
			reducedMotion,
			count: 20,
			rise: .22,
			size: .055,
			color: "#fff6e0",
			spread: 1.4
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				-.24,
				0
			],
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circleGeometry", { args: [2.2, 64] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#d9c7a0",
				roughness: .92
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				-.22,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circleGeometry", { args: [1.45, 32] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
				color: "#2a1a0c",
				transparent: true,
				opacity: .28
			})]
		})
	] });
}
function KhataiCanvas({ reducedMotion, onReady }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Canvas, {
		camera: {
			position: [
				0,
				1.12,
				3.05
			],
			fov: 34
		},
		dpr: [1, 1.6],
		gl: {
			antialias: true,
			alpha: true,
			powerPreference: "high-performance"
		},
		style: {
			pointerEvents: "none",
			width: "100%",
			height: "100%",
			background: "transparent"
		},
		frameloop: "always",
		onCreated: () => onReady?.(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene, { reducedMotion })
	});
}
//#endregion
export { KhataiCanvas as default };
