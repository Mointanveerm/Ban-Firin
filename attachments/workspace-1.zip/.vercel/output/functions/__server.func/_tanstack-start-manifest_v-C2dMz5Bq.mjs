//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C2dMz5Bq.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CnzijXyH.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CnzijXyH.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DMvaNmZE.js"]
	}
} });
//#endregion
export { tsrStartManifest };
