import { useEffect, useMemo, useRef } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";

function hash2(x: number, y: number) {
  const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123;
  return s - Math.floor(s);
}

function noise(x: number, y: number) {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  return (
    hash2(ix, iy) * (1 - ux) * (1 - uy) +
    hash2(ix + 1, iy) * ux * (1 - uy) +
    hash2(ix, iy + 1) * (1 - ux) * uy +
    hash2(ix + 1, iy + 1) * ux * uy
  );
}

function fbm(x: number, y: number) {
  return noise(x, y) * 0.55 + noise(x * 2.15, y * 2.15) * 0.28 + noise(x * 4.4, y * 4.4) * 0.17;
}

function buildKhataiGeometry() {
  const geo = new THREE.CylinderGeometry(1.28, 1.32, 0.3, 96, 8, false);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    const z = pos.getZ(i);
    const r = Math.hypot(x, z);
    const angle = Math.atan2(z, x);
    const wrinkle =
      Math.sin(angle * 7.0) * 0.014 +
      Math.sin(angle * 13.0 + 1.1) * 0.009 +
      (fbm(x * 2.4, z * 2.4) - 0.5) * 0.03;
    let ny = y;
    if (y > 0.04) {
      const t = Math.min(r / 1.28, 1);
      ny += (1 - t * t) * 0.07;
      ny += (fbm(x * 6.5, z * 6.5) - 0.45) * 0.05;
      if (fbm(x * 9, z * 9) > 0.72) ny -= 0.018;
    } else if (y < -0.04) {
      ny -= (fbm(x * 5, z * 5) - 0.5) * 0.012;
    }
    pos.setXYZ(i, x * (1 + wrinkle), ny, z * (1 + wrinkle));
  }
  geo.computeVertexNormals();
  return geo;
}

function makeCookieMaps() {
  const size = 512;
  const albedo = document.createElement("canvas");
  albedo.width = albedo.height = size;
  const ctx = albedo.getContext("2d");
  if (!ctx) throw new Error("canvas");

  const g = ctx.createRadialGradient(size * 0.5, size * 0.48, size * 0.04, size * 0.5, size * 0.5, size * 0.55);
  g.addColorStop(0, "#f0c57a");
  g.addColorStop(0.28, "#e0a84b");
  g.addColorStop(0.62, "#c47a30");
  g.addColorStop(0.86, "#9a5420");
  g.addColorStop(1, "#6d3514");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);

  const img = ctx.getImageData(0, 0, size, size);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (Math.random() - 0.5) * 32;
    d[i] = Math.max(0, Math.min(255, d[i] + n));
    d[i + 1] = Math.max(0, Math.min(255, d[i + 1] + n * 0.82));
    d[i + 2] = Math.max(0, Math.min(255, d[i + 2] + n * 0.45));
  }
  ctx.putImageData(img, 0, 0);

  for (let i = 0; i < 220; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    ctx.fillStyle = `rgba(82, 38, 12, ${0.06 + Math.random() * 0.2})`;
    ctx.beginPath();
    ctx.ellipse(x, y, 1 + Math.random() * 5, 0.6 + Math.random() * 2.4, Math.random() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }
  for (let i = 0; i < 50; i++) {
    ctx.fillStyle = `rgba(255, 236, 200, ${0.12 + Math.random() * 0.22})`;
    ctx.beginPath();
    ctx.arc(Math.random() * size, Math.random() * size, 0.6 + Math.random() * 1.1, 0, Math.PI * 2);
    ctx.fill();
  }

  const bump = document.createElement("canvas");
  bump.width = bump.height = size;
  const bctx = bump.getContext("2d");
  if (!bctx) throw new Error("canvas");
  bctx.fillStyle = "#808080";
  bctx.fillRect(0, 0, size, size);
  const bimg = bctx.getImageData(0, 0, size, size);
  const bd = bimg.data;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const v = Math.floor(fbm(x * 0.045, y * 0.045) * 255);
      const i = (y * size + x) * 4;
      bd[i] = bd[i + 1] = bd[i + 2] = v;
      bd[i + 3] = 255;
    }
  }
  bctx.putImageData(bimg, 0, 0);

  const albedoTex = new THREE.CanvasTexture(albedo);
  albedoTex.colorSpace = THREE.SRGBColorSpace;
  albedoTex.anisotropy = 8;
  albedoTex.needsUpdate = true;
  const bumpTex = new THREE.CanvasTexture(bump);
  bumpTex.needsUpdate = true;
  return { albedoTex, bumpTex };
}

function Khatai({ reducedMotion }: { reducedMotion: boolean }) {
  const group = useRef<THREE.Group>(null);
  const geo = useMemo(() => buildKhataiGeometry(), []);
  const maps = useMemo(() => makeCookieMaps(), []);

  useEffect(() => {
    return () => {
      geo.dispose();
      maps.albedoTex.dispose();
      maps.bumpTex.dispose();
    };
  }, [geo, maps]);

  useFrame((state, delta) => {
    if (!group.current || reducedMotion) return;
    const d = Math.min(delta, 0.1);
    group.current.rotation.y += 0.32 * d;
    group.current.position.y = Math.sin(state.clock.elapsedTime * 0.65) * 0.045;
  });

  return (
    <group ref={group} position={[0, 0.08, 0]}>
      <mesh geometry={geo} castShadow receiveShadow>
        <meshPhysicalMaterial
          map={maps.albedoTex}
          bumpMap={maps.bumpTex}
          bumpScale={0.085}
          roughness={0.5}
          metalness={0.03}
          clearcoat={0.62}
          clearcoatRoughness={0.26}
          sheen={0.55}
          sheenColor="#f3d9a0"
          sheenRoughness={0.42}
        />
      </mesh>
      <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, 0.03, 0]}>
        <torusGeometry args={[1.27, 0.018, 8, 64]} />
        <meshStandardMaterial color="#7a3f16" roughness={0.72} />
      </mesh>
      <mesh position={[0.02, 0.23, 0.04]} rotation={[0.55, 0.4, 0.7]} scale={[0.1, 0.048, 0.062]} castShadow>
        <sphereGeometry args={[1, 14, 10]} />
        <meshStandardMaterial color="#6f9444" roughness={0.55} />
      </mesh>
      <mesh position={[0.015, 0.245, 0.05]} rotation={[0.55, 0.4, 0.7]} scale={[0.055, 0.02, 0.03]}>
        <sphereGeometry args={[1, 10, 8]} />
        <meshStandardMaterial color="#c9d98a" roughness={0.4} />
      </mesh>
    </group>
  );
}

function Crumbs({ reducedMotion }: { reducedMotion: boolean }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const n = 16;
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const seeds = useMemo(
    () =>
      Array.from({ length: n }, (_, i) => ({
        r: 1.55 + (i % 5) * 0.14,
        y: -0.08 + (i % 7) * 0.05,
        speed: 0.12 + (i % 4) * 0.045,
        phase: i * 0.73,
        scale: 0.035 + (i % 3) * 0.014,
      })),
    [],
  );

  useFrame((state) => {
    if (!ref.current) return;
    const t = reducedMotion ? 0 : state.clock.elapsedTime;
    seeds.forEach((s, i) => {
      dummy.position.set(
        Math.cos(t * s.speed + s.phase) * s.r,
        s.y + Math.sin(t * 0.55 + s.phase) * 0.16,
        Math.sin(t * s.speed + s.phase) * s.r * 0.72,
      );
      dummy.rotation.set(t * 0.35 + i, t * 0.22, 0.4);
      dummy.scale.set(s.scale, s.scale * 0.45, s.scale * 0.7);
      dummy.updateMatrix();
      ref.current!.setMatrixAt(i, dummy.matrix);
    });
    ref.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={ref} args={[undefined, undefined, n]} castShadow>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color="#c47a30" roughness={0.82} />
    </instancedMesh>
  );
}

function Dust({
  reducedMotion,
  count,
  rise,
  size,
  color,
  spread,
}: {
  reducedMotion: boolean;
  count: number;
  rise: number;
  size: number;
  color: string;
  spread: number;
}) {
  const ref = useRef<THREE.Points>(null);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const a = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      a[i * 3] = (Math.random() - 0.5) * spread;
      a[i * 3 + 1] = Math.random() * 2.2 - 0.2;
      a[i * 3 + 2] = (Math.random() - 0.5) * spread * 0.8;
    }
    g.setAttribute("position", new THREE.BufferAttribute(a, 3));
    return g;
  }, [count, spread]);

  useEffect(() => () => geo.dispose(), [geo]);

  useFrame((_, delta) => {
    if (reducedMotion || !ref.current) return;
    const d = Math.min(delta, 0.1);
    const arr = ref.current.geometry.attributes.position.array as Float32Array;
    for (let i = 0; i < count; i++) {
      arr[i * 3 + 1] += d * rise;
      arr[i * 3] += Math.sin(arr[i * 3 + 1] * 2.2 + i) * d * 0.05;
      if (arr[i * 3 + 1] > 2.3) {
        arr[i * 3 + 1] = -0.2;
        arr[i * 3] = (Math.random() - 0.5) * spread;
        arr[i * 3 + 2] = (Math.random() - 0.5) * spread * 0.8;
      }
    }
    ref.current.geometry.attributes.position.needsUpdate = true;
  });

  return (
    <points ref={ref} geometry={geo}>
      <pointsMaterial color={color} size={size} transparent opacity={0.55} depthWrite={false} sizeAttenuation />
    </points>
  );
}

function AdaptiveCamera() {
  const { camera, size } = useThree();
  useEffect(() => {
    camera.position.set(0, size.width < 640 ? 1.35 : 1.12, size.width < 640 ? 3.7 : 3.05);
    camera.lookAt(0, 0.08, 0);
  }, [camera, size]);
  return null;
}

function Scene({ reducedMotion }: { reducedMotion: boolean }) {
  return (
    <>
      <AdaptiveCamera />
      <ambientLight intensity={0.7} color="#f3e2c0" />
      <directionalLight position={[3.2, 5.4, 2.2]} intensity={2.1} color="#ffe6bf" castShadow />
      <pointLight position={[-2.4, 2.1, 1.6]} intensity={16} distance={10} decay={2} color="#e8b968" />
      <pointLight position={[1.6, 0.4, -2.2]} intensity={8} distance={8} decay={2} color="#c9973d" />
      <Khatai reducedMotion={reducedMotion} />
      <Crumbs reducedMotion={reducedMotion} />
      <Dust reducedMotion={reducedMotion} count={70} rise={0.1} size={0.032} color="#f5efdd" spread={4.2} />
      <Dust reducedMotion={reducedMotion} count={20} rise={0.22} size={0.055} color="#fff6e0" spread={1.4} />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.24, 0]} receiveShadow>
        <circleGeometry args={[2.2, 64]} />
        <meshStandardMaterial color="#d9c7a0" roughness={0.92} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.22, 0]}>
        <circleGeometry args={[1.45, 32]} />
        <meshBasicMaterial color="#2a1a0c" transparent opacity={0.28} />
      </mesh>
    </>
  );
}

export default function KhataiCanvas({
  reducedMotion,
  onReady,
}: {
  reducedMotion: boolean;
  onReady?: () => void;
}) {
  return (
    <Canvas
      camera={{ position: [0, 1.12, 3.05], fov: 34 }}
      dpr={[1, 1.6]}
      gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
      style={{ pointerEvents: "none", width: "100%", height: "100%", background: "transparent" }}
      frameloop="always"
      onCreated={() => onReady?.()}
    >
      <Scene reducedMotion={reducedMotion} />
    </Canvas>
  );
}
